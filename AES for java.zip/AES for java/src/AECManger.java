
public class AECManger {
	public static void main(String[] args) {

		String originalText = "123";
		AES mAes = new AES();
		String resault1 = mAes.encrypt(originalText.getBytes());

		String readString = mAes.decrypt(resault1);

	}
}