//
//  YRotationViewController.h
//  RotationDemo
//
//  Created by vivo on 16/1/9.
//  Copyright © 2016年 vivo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface YRotationViewController : NSViewController
@property (weak) IBOutlet NSView *ContainerView;
@property (weak) IBOutlet NSButton *clickButton;

@end
