//
//  ViewController.m
//  RotationDemo
//
//  Created by vivo on 16/1/9.
//  Copyright © 2016年 vivo. All rights reserved.
//

#import "RotationViewController.h"

@implementation RotationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setWantsLayer:YES];
    // Do any additional setup after loading the view.
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}

@end
