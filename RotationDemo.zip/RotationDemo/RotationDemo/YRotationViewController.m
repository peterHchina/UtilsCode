//
//  YRotationViewController.m
//  RotationDemo
//
//  Created by vivo on 16/1/9.
//  Copyright © 2016年 vivo. All rights reserved.
//

#import "YRotationViewController.h"
#import <QuartzCore/QuartzCore.h>
@interface YRotationViewController ()
{
    CALayer * layer;
    BOOL isStop ;
}
@end

@implementation YRotationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    isStop = NO;
    self.view.wantsLayer = YES;
    self.ContainerView.wantsLayer = YES;
    // Do view setup here.
     [self rotationAnimation];
}

-(void) rotationAnimation
{
    layer = [CALayer layer];
    layer.contents = (id)[NSImage imageNamed:@"cover_image"];
    layer.borderColor = [NSColor grayColor].CGColor;
    layer.borderWidth = 1.0;
    layer.masksToBounds = YES;
    layer.cornerRadius = 100;
    layer.bounds= CGRectMake(self.ContainerView.bounds.origin.x+self.ContainerView.bounds.size.width/2, self.view.bounds.origin.y+self.view.bounds.size.height/2+100, 200, 200);
    layer.position = CGPointMake(self.ContainerView.bounds.origin.x+self.ContainerView.bounds.size.width/2, self.ContainerView.bounds.origin.y+self.ContainerView.bounds.size.height/2);
    
    //    layer.anchorPoint = CGPointMake(0.5, 0.5);
    
    CABasicAnimation * animation = [CABasicAnimation animation];
    animation.keyPath = @"transform.rotation.y";
    animation.duration = 4;
    animation.repeatCount = MAXFLOAT;
    animation.fromValue =@0;
    animation.toValue=@(2*M_PI);
    animation.cumulative = YES;
    animation.removedOnCompletion = NO;
    animation.fillMode = kCAFillModeForwards;
    [layer addAnimation:animation forKey:@""];
    [self.ContainerView.layer addSublayer:layer];
    
    
}

-(void) pauseLayer:(CALayer *) alayer
{
    CFTimeInterval pausedTime = [alayer convertTime:CACurrentMediaTime() fromLayer:nil];
    alayer.speed = 0;
    alayer.timeOffset = pausedTime;
}

-(void) resumLayer:(CALayer *) alayer
{
    CFTimeInterval pausedTime = [alayer timeOffset];
    alayer.speed = 1.0;
    alayer.timeOffset = pausedTime;
    alayer.beginTime = 0.0;
    CFTimeInterval timeSincePause = [alayer convertTime:CACurrentMediaTime() fromLayer:nil]-pausedTime;
    alayer.beginTime = timeSincePause;
    
}
- (IBAction)clickButton:(id)sender {
    if (isStop) {
        [self restart];
    }else
    {
        [self pause];
    }
}

-(void) pause
{
    [self.clickButton setTitle:@"start"];
    isStop = YES;
    [self pauseLayer:layer];
}

-(void) restart
{
    isStop = NO;
    [self.clickButton setTitle:@"stop"];
    [self resumLayer:layer];
}



@end
