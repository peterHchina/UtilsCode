//
//  main.m
//  RotationDemo
//
//  Created by vivo on 16/1/9.
//  Copyright © 2016年 vivo. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
