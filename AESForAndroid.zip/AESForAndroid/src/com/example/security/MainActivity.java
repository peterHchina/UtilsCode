package com.example.security;

import java.security.SecureRandom;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import android.os.Bundle;
import android.app.Activity;
import android.util.Log;
import android.view.Menu;
public class MainActivity extends Activity
{


	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
	
	   // ��Ҫ���ܵ��ִ�
    String cSrc = "[{\"request_no\":\"1001\",\"service_code\":\"FS0001\",\"contract_id\":\"100002\",\"order_id\":\"0\",\"phone_id\":\"13913996922\",\"plat_offer_id\":\"100094\",\"channel_id\":\"1\",\"activity_id\":\"100045\"}]";
    
    // ����
    long lStart = System.currentTimeMillis();
    String enString="";
	try
	{
		enString = NewAES.getInstance().encrypt(cSrc);
	}
	catch (Exception e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    System.out.println("���ܺ���ִ��ǣ�" + enString);

    long lUseTime = System.currentTimeMillis() - lStart;
    System.out.println("���ܺ�ʱ��" + lUseTime + "����");
    // ����
    lStart = System.currentTimeMillis();
    String DeString="";
	try
	{
		DeString = NewAES.getInstance().decrypt(enString);
	}
	catch (Exception e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
    System.out.println("���ܺ���ִ��ǣ�" + DeString);
    lUseTime = System.currentTimeMillis() - lStart;
    System.out.println("���ܺ�ʱ��" + lUseTime + "����");
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
